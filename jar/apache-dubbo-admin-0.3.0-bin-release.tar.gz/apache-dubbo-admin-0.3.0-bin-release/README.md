* run: java -jar dubbo-admin-${project.version}.jar
* modify properties in `application.properties`
